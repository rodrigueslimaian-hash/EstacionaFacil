# EstacionaFácil — Engenharia de Software

## Escopo
O projeto do professor descreve um **Sistema Inteligente de Análise de Satisfação e Gestão de Indicadores para o EstacionaFácil**. O foco é receber avaliações, identificar o serviço, analisar sentimento com PLN, mostrar indicadores e gerar alertas.

Documentação de referência: `desafio_estacionafacil.docx` e orientações da atividade enviadas em 19/11/2026.

## Como testar o protótipo
1. Abra `prototipo/index.html` em um navegador.
2. Entre com qualquer usuário e senha e selecione um perfil (login simulado).
3. Navegue pelas abas Dashboard, Avaliações, Importação, Serviços e Alertas.
4. Experimente cadastrar uma avaliação, importar um CSV/JSON ou modificar o limite de alertas.
5. Recarregar a página restaura os dados demonstrativos: não há banco ou armazenamento persistente.

CSV de exemplo: `exemplo_avaliacoes.csv` (a importação CSV aceita somente valores simples sem vírgula dentro dos campos). O JSON aceita uma lista de objetos com `servico`, `comentario`, `contrato` e `veiculo`.

## Diagramas
- `diagramas/01_casos_de_uso.puml`: atores e funções (UML / PlantUML)
- `diagramas/02_atividades.puml`: processo de avaliação (UML / PlantUML)
- `diagramas/03_classes.puml`: entidades do domínio (UML / PlantUML)
- `diagramas/04_sequencia.puml`: comunicação entre componentes (UML / PlantUML)
- `diagramas/05_modelo_der.mmd`: modelo conceitual-relacional (Mermaid ER)

Para visualizar os arquivos `.puml`, use o PlantUML no VS Code ou a ferramenta PlantUML. Para o `.mmd`, use Mermaid Live Editor ou um arquivo Markdown do GitHub com bloco `mermaid`. O DER é uma proposta inicial para desenhar e refinar no MySQL Workbench, **não** um arquivo nativo do Workbench.

## Relação entre requisitos e telas
| Requisito | Demonstração no protótipo |
| --- | --- |
| RF01 | Importação CSV/JSON; integração externa apenas modelada |
| RF02 e RF03 | Seleção de serviço e classificação didática por palavras-chave |
| RF04 | Dashboard com métricas e ranking por porcentagem positiva |
| RF05 | Cadastro e inativação de categorias; planos e perfis pendentes |
| RF06 | Alertas atualizados quando percentual positivo cai abaixo de um limite |
| RF07 | Filtros de período, contrato e veículo |

## Limitações importantes
- Dados de exemplo e armazenamento só em memória.
- Classificação **não é PLN real**: é demonstração por lista de palavras positivas/negativas, pode falhar em negações, sarcasmo e feedbacks mistos. A API Python está prevista para o produto final.
- Login e restrição de perfil são apenas demonstração de interface, **não** segurança real ou implementação da LGPD.
- Não existe MySQL, backend, integração automática com app, análise de volume, nem garantia de RNF05 (1000 avaliações em menos de 1 minuto).
- A inferência de serviço no protótipo é realizada por seleção explícita; o produto real deverá vincular corretamente a avaliação ao registro do serviço e/ou usar classificação automática.
- O diagrama de classes descreve o modelo pretendido do sistema completo, não apenas a interface já codificada.

## Plano de trabalho em grupo
1. Conferir requisitos e modelo de classes com a pessoa responsável pela especificação.
2. Revisar os quatro diagramas UML, sobretudo o fluxo de avaliações e papéis.
3. Desenhar o DER definitivo no MySQL Workbench.
4. Replicar as telas no Figma, caso o professor exija protótipos naquela ferramenta; usar HTML como protótipo navegável complementar.
5. Implementar API, MySQL e PLN em Python numa próxima fase, integrar testes e medir desempenho.

## Controle de versão sugerido
Repositório GitHub com pastas `documentacao/`, `diagramas/`, `prototipo/` e futuramente `backend/` e `banco/`. Criar branches por funcionalidade, abrir pull requests para revisão e marcar versões `v0.1-prototipo`, `v0.2-integracao` etc.
