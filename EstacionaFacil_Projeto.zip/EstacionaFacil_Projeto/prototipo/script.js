// Protótipo didático: todos os dados ficam apenas em memória.
const hoje = new Date();
const dataHa = (dias) => { const d = new Date(hoje); d.setDate(d.getDate() - dias); return d.toISOString().slice(0, 10); };
let servicos = ['Vaga avulsa', 'Vaga coberta', 'Lava-jato', 'Estética', 'Manobrista', 'App/reserva', 'Pernoite', 'Contrato mensal'].map(nome => ({ nome, ativo: true }));
let avaliacoes = [
  ['Vaga coberta','Gostei da segurança e do local coberto.','Positivo','Mensal','Carro pequeno',1],
  ['Lava-jato','Meu carro ficou sujo e o serviço atrasou.','Negativo','Avulso','Carro pequeno',2],
  ['Manobrista','Atendimento rápido e excelente.','Positivo','Avulso','Carro grande',3],
  ['App/reserva','O aplicativo travou e não consegui reservar.','Negativo','Semanal','Moto',4],
  ['Pernoite','O valor foi razoável.','Neutro','Avulso','Carro pequeno',5],
  ['Lava-jato','Péssima limpeza, demorado e caro.','Negativo','Mensal','Carro grande',6],
  ['Vaga avulsa','Fácil de estacionar, ótimo atendimento.','Positivo','Avulso','Moto',9],
  ['Estética','Gostei do acabamento, excelente resultado.','Positivo','Semanal','Carro pequeno',11],
  ['Contrato mensal','O contrato funciona como esperado.','Neutro','Mensal','Carro grande',13],
  ['App/reserva','Reserva simples e rápida.','Positivo','Mensal','Moto',20],
  ['Vaga coberta','Espaço confortável e seguro.','Positivo','Mensal','Carro grande',24],
  ['Lava-jato','Demora excessiva, atendimento ruim.','Negativo','Avulso','Carro pequeno',35]
].map(([servico,comentario,sentimento,contrato,veiculo,dias]) => ({servico,comentario,sentimento,contrato,veiculo,data:dataHa(dias),palavras:[]}));
let limite = 50;
let perfil = 'Gerente';
const $ = (id) => document.getElementById(id);
const seguro = (v) => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const palavrasPositivas = ['bom','boa','excelente','ótimo','otimo','rápido','rapido','gostei','seguro','segurança','facil','fácil','limpo','confortável','confortavel'];
const palavrasNegativas = ['ruim','péssimo','pessimo','péssima','pessima','demora','demorado','atrasou','sujo','caro','travou','problema','difícil','dificil'];
function analisar(texto){
  const palavras = (texto.toLowerCase().match(/[a-zà-ú]+/gi) || []);
  const p = palavras.filter(x=>palavrasPositivas.includes(x)).length;
  const n = palavras.filter(x=>palavrasNegativas.includes(x)).length;
  return { sentimento: p > n ? 'Positivo' : n > p ? 'Negativo' : 'Neutro', palavras: [...new Set(palavras.filter(x=>palavrasPositivas.includes(x)||palavrasNegativas.includes(x)))].slice(0,5) };
}
function aviso(texto){$('notificacao').textContent=texto;$('notificacao').classList.remove('hidden');}
function filtradas(){
 const periodo=$('f-periodo').value, contrato=$('f-contrato').value, veiculo=$('f-veiculo').value;
 return avaliacoes.filter(a=> (periodo==='todos'||new Date(a.data)>=new Date(dataHa(Number(periodo)))) && (contrato==='todos'||a.contrato===contrato) && (veiculo==='todos'||a.veiculo===veiculo));
}
function contagem(lista, sentimento){return lista.filter(a=>a.sentimento===sentimento).length;}
function estatisticas(lista){return servicos.filter(s=>s.ativo).map(s=>{let dados=lista.filter(a=>a.servico===s.nome);return {nome:s.nome,total:dados.length,pct:dados.length?Math.round(100*contagem(dados,'Positivo')/dados.length):null};});}
function alertas(){return estatisticas(avaliacoes).filter(s=>s.total>0&&s.pct<limite);}
function renderDashboard(){
 const lista=filtradas(),total=lista.length,pos=contagem(lista,'Positivo'),neg=contagem(lista,'Negativo'),neu=contagem(lista,'Neutro');
 $('k-total').textContent=total;$('k-positivas').textContent=(total?Math.round(pos/total*100):0)+'%';$('k-negativas').textContent=neg;$('k-alertas').textContent=alertas().length;
 $('grafico-servicos').innerHTML=estatisticas(lista).map(s=>`<div class="bar-row"><span>${seguro(s.nome)}</span><div class="bar-bg"><div class="bar-fill ${s.pct!==null && s.pct<limite?'low':''}" style="width:${s.pct??0}%"></div></div><strong>${s.pct===null?'—':s.pct+'%'}</strong></div>`).join('') || 'Nenhum serviço ativo.';
 const percent=n=>total?100*n/total:0;
 $('grafico-sentimentos').innerHTML=`<div class="sentiment"><div class="positivo" style="width:${percent(pos)}%"></div><div class="neutro" style="width:${percent(neu)}%"></div><div class="negativo" style="width:${percent(neg)}%"></div></div><div class="legenda"><b><i class="legend-dot positivo"></i>Positivo ${pos}</b><b><i class="legend-dot neutro"></i>Neutro ${neu}</b><b><i class="legend-dot negativo"></i>Negativo ${neg}</b></div>`;
 $('recentes').innerHTML=[...lista].sort((a,b)=>b.data.localeCompare(a.data)).slice(0,3).map(a=>`<div class="comment"><small>${seguro(a.servico)} · ${a.data}</small><p>${seguro(a.comentario)}</p><span class="tag ${a.sentimento}">${a.sentimento}</span></div>`).join('')||'<p>Não há avaliações para os filtros atuais.</p>';
 $('menu-alertas').textContent=alertas().length?`(${alertas().length})`:'';
}
function renderAvaliacoes(){const sentimento=$('f-sentimento').value;const lista=[...avaliacoes].filter(a=>sentimento==='todos'||a.sentimento===sentimento).sort((a,b)=>b.data.localeCompare(a.data));$('tabela-avaliacoes').innerHTML=lista.map(a=>`<tr><td>${a.data}</td><td>${seguro(a.servico)}</td><td>${seguro(a.comentario)}</td><td>${seguro(a.contrato)}</td><td>${seguro(a.veiculo)}</td><td><span class="tag ${a.sentimento}">${a.sentimento}</span></td></tr>`).join('')||'<tr><td colspan="6">Nenhum registro encontrado.</td></tr>';}
function renderServicos(){ $('lista-servicos').innerHTML=servicos.map((s,i)=>`<div class="service"><span>${seguro(s.nome)} <small class="tag">${s.ativo?'Ativo':'Inativo'}</small></span><button data-toggle="${i}" ${perfil==='Operador'?'disabled':''}>${s.ativo?'Inativar':'Ativar'}</button></div>`).join('');$('novo-servico').innerHTML=servicos.filter(s=>s.ativo).map(s=>`<option>${seguro(s.nome)}</option>`).join('');}
function renderAlertas(){ $('valor-limite').textContent=limite+'%';$('limite').value=limite;const a=alertas(); $('lista-alertas').innerHTML=a.map(s=>`<div class="alert"><span><strong>${seguro(s.nome)}</strong><br><small>${s.pct}% positivas em ${s.total} avaliação(ões)</small></span><span class="tag Negativo">Atenção</span></div>`).join('')||'<p>Nenhum serviço está abaixo do limite. Serviços sem avaliações não são classificados.</p>'; }
function render(){renderDashboard();renderAvaliacoes();renderServicos();renderAlertas();}
const titulos={dashboard:['Visão geral','Acompanhe a satisfação dos clientes e os serviços.'],avaliacoes:['Avaliações','Comentários recebidos e classificação de sentimentos.'],importacao:['Importar avaliações','Adicione comentários e simule a análise automática.'],servicos:['Serviços','Gerencie as categorias disponíveis.'],alertas:['Monitoramento de alertas','Identifique serviços abaixo do nível esperado.']};
function pagina(nome){document.querySelectorAll('.pagina').forEach(p=>p.classList.toggle('hidden',p.id!==nome));document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.page===nome));$('titulo').textContent=titulos[nome][0];$('subtitulo').textContent=titulos[nome][1];$('breadcrumb').textContent=nome.toUpperCase();$('notificacao').classList.add('hidden');render();}
$('login-form').addEventListener('submit',e=>{e.preventDefault();perfil=$('perfil').value;$('login').classList.add('hidden');$('app').classList.remove('hidden');$('perfil-atual').textContent=perfil;pagina('dashboard');});
$('sair').addEventListener('click',()=>{$('app').classList.add('hidden');$('login').classList.remove('hidden');});
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>pagina(b.dataset.page)));
['f-periodo','f-contrato','f-veiculo'].forEach(id=>$(id).addEventListener('change',renderDashboard));
$('f-sentimento').addEventListener('change',renderAvaliacoes);
$('limpar-filtros').addEventListener('click',()=>{['f-periodo','f-contrato','f-veiculo'].forEach(id=>$(id).value='todos');renderDashboard();});
$('form-avaliacao').addEventListener('submit',e=>{e.preventDefault();const comentario=$('novo-comentario').value.trim();if(!comentario)return;const res=analisar(comentario);avaliacoes.push({servico:$('novo-servico').value,contrato:$('novo-contrato').value,veiculo:$('novo-veiculo').value,comentario,data:dataHa(0),...res});$('resultado-analise').innerHTML=`<p class="tip">Resultado demonstrativo: <span class="tag ${res.sentimento}">${res.sentimento}</span> · Palavras-chave: ${seguro(res.palavras.join(', ')||'nenhuma identificada')}</p>`;$('novo-comentario').value='';render();aviso('Avaliação adicionada com sucesso (somente em memória).');});
$('form-servico').addEventListener('submit',e=>{e.preventDefault();if(perfil==='Operador'){aviso('O perfil Operador não pode cadastrar categorias.');return;}let nome=$('nome-servico').value.trim();if(servicos.some(s=>s.nome.toLowerCase()===nome.toLowerCase())){aviso('Essa categoria já existe.');return;}servicos.push({nome,ativo:true});$('nome-servico').value='';render();aviso('Categoria adicionada.');});
$('lista-servicos').addEventListener('click',e=>{const b=e.target.closest('[data-toggle]');if(!b||perfil==='Operador')return;servicos[Number(b.dataset.toggle)].ativo=!servicos[Number(b.dataset.toggle)].ativo;render();});
$('limite').addEventListener('input',e=>{limite=Number(e.target.value);renderAlertas();renderDashboard();});
function parseCSV(texto){const linhas=texto.replace(/\r/g,'').trim().split('\n');const cab=linhas.shift().split(',').map(s=>s.trim().toLowerCase());for(const campo of ['servico','comentario'])if(!cab.includes(campo))throw new Error('CSV sem coluna '+campo);return linhas.filter(l=>l.trim()).map(l=>{const valores=l.split(',').map(s=>s.trim());return Object.fromEntries(cab.map((campo,i)=>[campo,valores[i]||'']));});}
$('importar-arquivo').addEventListener('click',async()=>{const arquivo=$('arquivo').files[0];if(!arquivo){aviso('Selecione um arquivo CSV ou JSON.');return;}try{let dados=arquivo.name.toLowerCase().endsWith('.json')?JSON.parse(await arquivo.text()):parseCSV(await arquivo.text());if(!Array.isArray(dados))throw new Error('O JSON precisa conter uma lista.');let adicionadas=0;for(const d of dados){if(!d.servico||!d.comentario||!servicos.some(s=>s.nome===d.servico&&s.ativo))continue;avaliacoes.push({servico:d.servico,comentario:d.comentario,contrato:d.contrato||'Avulso',veiculo:d.veiculo||'Carro pequeno',data:dataHa(0),...analisar(d.comentario)});adicionadas++;}render();aviso(`${adicionadas} avaliação(ões) importada(s). Dados não são salvos no servidor.`);}catch(erro){aviso('Falha na importação: '+erro.message);}});
render();
